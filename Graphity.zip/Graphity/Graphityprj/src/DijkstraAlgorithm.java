import java.util.*;
public class DijkstraAlgorithm {
    private GraphRepresentation graph;
    
    public DijkstraAlgorithm(GraphRepresentation graph){
        this.graph = graph;
     }
    public Map<GraphNode, Integer> execute(GraphNode startNode){
       Map<GraphNode, Integer> dist = new HashMap<>();
        Map<GraphNode, GraphNode> parentNode = new HashMap<>(); 
        PriorityQueue<GraphNode> priorityQueue = new PriorityQueue<>(Comparator.comparingInt(dist::get));
       for (GraphNode node : graph.getNodes()) {
            dist.put(node, Integer.MAX_VALUE);
        }
        dist.put(startNode, 0);
       priorityQueue.add(startNode);
          while (!priorityQueue.isEmpty()) {
           GraphNode currentNode = priorityQueue.poll();
             for (GraphNode neighbor : graph.getNeighbors(currentNode)){
                int newDist = dist.get(currentNode) + getEdgeWeight(currentNode, neighbor);
                 if (newDist < dist.get(neighbor)) {
                 dist.put(neighbor, newDist);
                parentNode.put(neighbor, currentNode);
               priorityQueue.add(neighbor);
                }
                 }
                }
        highlightPaths(parentNode);
        return dist;
    }
    private int getEdgeWeight(GraphNode from, GraphNode to) {
       for (GraphEdge edge : graph.getEdges()){
            if ((edge.getFrom().equals(from) && edge.getTo().equals(to)) || 
                 (edge.getTo().equals(from) && edge.getFrom().equals(to))) {
                return edge.getWeight();
            }
              }
        return Integer.MAX_VALUE;
    }
    private void highlightPaths(Map<GraphNode, GraphNode> parentNode){
         graph.clearHighlights();
        for (Map.Entry<GraphNode, GraphNode> entry : parentNode.entrySet()){
           GraphNode node = entry.getKey();
            GraphNode predecessor = entry.getValue();
             for (GraphEdge edge : graph.getEdges()) {
                if ((edge.getFrom().equals(predecessor) && edge.getTo().equals(node))  ||
                     (edge.getTo().equals(predecessor) && edge.getFrom().equals(node))){
                    graph.highlightEdge(edge);
                   break;
                }
                }
           graph.highlightNode(node);
        }
        if (!parentNode.isEmpty()){
             GraphNode startNode = parentNode.values().iterator().next();
            graph.highlightNode(startNode);
        }
     }
    }
