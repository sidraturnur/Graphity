import java.util.*;

public class DepthFirstSearch{
    private GraphRepresentation graph;
    public DepthFirstSearch(GraphRepresentation graph){
       this.graph = graph;
    }
    public List<GraphNode> execute(GraphNode startNode)
    {
        graph.clearHighlights();
         List<GraphNode> visitedNodes = new ArrayList<>();
          List<GraphNode> result = new ArrayList<>();
        dfsVisit(startNode, visitedNodes, result);
        return result;
    }
    private void dfsVisit(GraphNode node, List<GraphNode> visitedNodes, List<GraphNode> result){
        if (visitedNodes.contains(node)){
            return;
        }
        visitedNodes.add(node);
        result.add(node); 
         graph.getHighlightedNodes().add(node); 
        for (GraphEdge edge : graph.getEdgesFrom(node)) {
             GraphNode neighbor = edge.getTo();
            if (!visitedNodes.contains(neighbor)) {
                 graph.getHighlightedEdges().add(edge);
                dfsVisit(neighbor, visitedNodes, result);
            }
        }
           }
    public List<GraphNode> executeForDisconnectedGraph(){
       graph.clearHighlights();
         List<GraphNode> visitedNodes = new ArrayList<>();
        List<GraphNode> result = new ArrayList<>();
       for (GraphNode node : graph.getAllNodes()) {
         if (!visitedNodes.contains(node)) {
         dfsVisit(node, visitedNodes, result);
            }
             }

        return result;
  }
}


