import java.awt.Point;
import java.awt.Rectangle;

public class GraphNode{
    private Point position;
    private String name;
    private static int nodeCounter = 0;
    public GraphNode(Point position){
         this.position = position;
        this.name = "Node " + (++nodeCounter);
    }
    public Point getPosition(){
       return position;
    }
    public String getName(){
      return name;
    }
    public Rectangle getBounds() {
        int diameter = 20;
        return new Rectangle(position.x - diameter / 2, position.y - diameter / 2, diameter, diameter);
    }
    public int getX(){
        return position.x;
    }
    public int getY(){
        return position.y;
    }
}
