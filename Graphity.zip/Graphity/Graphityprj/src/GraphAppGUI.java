import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.List;

public class GraphAppGUI extends JFrame{
    private JPanel drawingPanel;
     private JTextArea outputArea;
     private JTextField edgeWeightField;
    private JTextField startNodeField;
     private GraphRepresentation graph; 
     private GraphNode selectedNode;
     private GraphNode edgeStartNode;
     private GraphNode edgeEndNode;
 public GraphAppGUI()  {
       setTitle("Graphity");
        setSize(1000, 700);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
       setLayout(new BorderLayout());
       graph = new GraphRepresentation();
         drawingPanel= new JPanel(){
        @Override
           protected void paintComponent(Graphics g){
                super.paintComponent(g);
                drawGraph(g);
            }
        };
        drawingPanel.setBackground(Color.WHITE);
        drawingPanel.addMouseListener(new MouseAdapter(){
            @Override
            public void mouseClicked(MouseEvent e){
                handleMouseClick(e.getPoint());
            }
        }); 
        JPanel controlPanel = new JPanel();
         controlPanel.setLayout(new BoxLayout(controlPanel, BoxLayout.Y_AXIS));
         controlPanel.setPreferredSize(new Dimension(500, 600));
        controlPanel.setBackground(new Color(200, 162, 200));
        edgeWeightField = new JTextField(5);
        edgeWeightField.setPreferredSize(new Dimension(10, 20));
        startNodeField = new JTextField(5);
        startNodeField.setPreferredSize(new Dimension(10, 20));
        controlPanel.add(new JLabel("Edge Weight:"));
        edgeWeightField.setHorizontalAlignment(SwingConstants.LEFT);
        controlPanel.add(edgeWeightField);
        controlPanel.add(new JLabel("Start Node (for BFS/DFS/Prim's/Dijkstra):"));
        edgeWeightField.setHorizontalAlignment(SwingConstants.LEFT);
        controlPanel.add(startNodeField);
        JButton removeNodeButton = new JButton("Remove Node");
        JButton removeEdgeButton = new JButton("Remove Edge");
        JButton runBFSButton = new JButton("Run BFS");
        JButton runDFSButton = new JButton("Run DFS");
        JButton runPrimButton = new JButton("Run Prim's");
        JButton runKruskalButton = new JButton("Run Kruskal's");
        JButton runDijkstraButton = new JButton("Run Dijkstra's");
        JButton compareButton = new JButton("Compare Algorithms");
        Color lilac = new Color(200, 162, 200);
        Color textColor = Color.BLACK;
        JButton[] buttons = {
            removeNodeButton, removeEdgeButton, runBFSButton, runDFSButton, 
            runPrimButton, runKruskalButton, runDijkstraButton, compareButton
        };
        for (JButton button : buttons){
            button.setBackground(lilac);
         button.setForeground(textColor);
        }
        JPanel buttonPanel = new JPanel();
       buttonPanel.setLayout(new GridLayout(4, 2, 5, 5));
        buttonPanel.add(removeNodeButton);
       buttonPanel.add(removeEdgeButton);
       buttonPanel.add(runBFSButton);
       buttonPanel.add(runDFSButton);
       buttonPanel.add(runPrimButton);
        buttonPanel.add(runKruskalButton);
       buttonPanel.add(runDijkstraButton);
       buttonPanel.add(compareButton);
        controlPanel.add(buttonPanel);
      outputArea = new JTextArea(15, 40);
       outputArea.setEditable(false);
       JScrollPane scrollPane = new JScrollPane(outputArea);
       scrollPane.setPreferredSize(new Dimension(400, 300));
      controlPanel.add(scrollPane);
      add(drawingPanel, BorderLayout.CENTER);
       add(controlPanel, BorderLayout.WEST);
       removeNodeButton.addActionListener(e -> removeNode());
        removeEdgeButton.addActionListener(e -> removeEdge());
        runBFSButton.addActionListener(e -> runBFS());
       runDFSButton.addActionListener(e -> runDFS());
       runPrimButton.addActionListener(e -> runPrim());
        runKruskalButton.addActionListener(e -> runKruskal());
        runDijkstraButton.addActionListener(e -> runDijkstra());
        compareButton.addActionListener(e -> compareAlgorithms());
    }
 private void handleMouseClick(Point point){
	    GraphNode clickedNode = graph.getNodeAtPosition(point);
	    if (clickedNode != null){
	        if (selectedNode == null){
	         selectedNode = clickedNode;
	        outputArea.append("Selected: " + selectedNode.getName() + "\n");
	        }else{
	        if (selectedNode == clickedNode){
	       outputArea.append("Cannot add an edge from a node to itself.\n");
	      } else {
	            try {
	               int weight = Integer.parseInt(edgeWeightField.getText());
	             graph.addEdge(selectedNode, clickedNode, weight);
	               outputArea.append("Added edge from " + selectedNode.getName() + " to " + clickedNode.getName() + " with weight " + weight + "\n");
	               } catch (NumberFormatException e) {
	                outputArea.append("Invalid weight. Please enter a valid integer.\n");
	               }
	                 }
	            selectedNode = null;
	                 }
	    }else{
	        addNode(point);
	    }
	    drawingPanel.repaint();
	}
    private void addNode(Point point)   {
       GraphNode newNode = new GraphNode(point);
         graph.addNode(newNode);
          drawingPanel.repaint();
    }
    private void drawGraph(Graphics g){
   Graphics2D g2d = (Graphics2D) g;
   for (GraphEdge edge : graph.getEdges()){
           if (graph.getHighlightedEdges().contains(edge)){
               g2d.setColor(Color.RED);
                g2d.setStroke(new BasicStroke(3)); 
           }else{
               g2d.setColor(Color.BLACK); 
                g2d.setStroke(new BasicStroke(2)); 
            }
           g2d.drawLine(
               edge.getFrom().getX(), edge.getFrom().getY(),
              edge.getTo().getX(), edge.getTo().getY()
            );
           g2d.setColor(Color.RED);
          g2d.setFont(new Font("Arial", Font.BOLD, 12)); 
           g2d.drawString(
                String.valueOf(edge.getWeight()),
                  (edge.getFrom().getX() + edge.getTo().getX()) / 2,
                 (edge.getFrom().getY() + edge.getTo().getY()) / 2 - 15
            );
        }
        for (GraphNode node : graph.getNodes())  
        {
            if (graph.getHighlightedNodes().contains(node)){
                g2d.setColor(Color.BLUE);
            } else{
                g2d.setColor(Color.BLACK);
              }
             g2d.fillOval(node.getX() - 10, node.getY() - 10, 20, 20);
              g2d.setColor(Color.BLACK);
            g2d.drawString(node.getName(), node.getX() + 12, node.getY());
        }
    }
    private void removeNode(){
    	    if (selectedNode != null){
    	          graph.removeNode(selectedNode);
    	        outputArea.append("Removed node: " + selectedNode.getName() + "\n");
    	          selectedNode = null;
    	         drawingPanel.repaint();
    	    }else{
    	         outputArea.append("No node selected to remove.\n");
    	    }	
    }
    private void removeEdge(){
        outputArea.append("Click the first node to remove an edge.\n");
         drawingPanel.addMouseListener(new MouseAdapter(){
            @Override
             public void mouseClicked(MouseEvent e){
            Point clickPoint = e.getPoint();
           if (edgeStartNode == null){
          edgeStartNode = graph.getNodeAtPosition(clickPoint);
          if (edgeStartNode != null) 
          {
            outputArea.append("First node selected: " + edgeStartNode.getName() + ". Now, click the second node.\n");
          } else{
           outputArea.append("No node found at the first selected position.\n");
                    }
                }else{
                GraphNode edgeEndNode = graph.getNodeAtPosition(clickPoint);
                 if (edgeEndNode != null){
                  graph.removeEdge(edgeStartNode, edgeEndNode);
                outputArea.append("Removed edge between " + edgeStartNode.getName() + " and " + edgeEndNode.getName() + ".\n");
                 }else{
                  outputArea.append("No node found at the second selected position.\n");
                }
                  edgeStartNode = null;
                drawingPanel.removeMouseListener(this); 
                }
                  drawingPanel.repaint();
            }
        }); 
    }
    private void runBFS(){
        String startNodeName = startNodeField.getText();
        try {
            if (startNodeName == null || startNodeName.trim().isEmpty())
            {
                throw new IllegalArgumentException("Start node name cannot be empty.");
            }
            GraphNode startNode = graph.getNodeByName(startNodeName);
             if (startNode == null){
                throw new NoSuchElementException("Start node '" + startNodeName + "' not found in the graph.");
            }
             outputArea.append("Running BFS from " + startNode.getName() + "...\n");
            long startTime = System.nanoTime();
             List<GraphNode> bfsResult = graph.bfs(startNode);
             long endTime = System.nanoTime();
             outputArea.append("BFS Result: ");
            for (GraphNode node : bfsResult) {
                outputArea.append(node.getName() + " , ");
            }
            outputArea.append("\nTime taken: " + (endTime - startTime) / 1_000_000 + " ms\n");
         }catch (IllegalArgumentException e){
            outputArea.append("Warning: " + e.getMessage() + "\n");
         }catch (NoSuchElementException e) {
            outputArea.append("Warning: " + e.getMessage() + "\n");
        }catch (Exception e) {
            outputArea.append("An unexpected error occurred: " + e.getMessage() + "\n");
          }finally{
            drawingPanel.repaint();
          }
        }

    

    	private void runDFS(){
    	    String startNodeName= startNodeField.getText();
    	    try {
    	          if (startNodeName == null || startNodeName.trim().isEmpty()) {
    	            throw new IllegalArgumentException("Start node name cannot be empty.");
    	         }
    	         GraphNode startNode = graph.getNodeByName(startNodeName);
    	        if (startNode == null){
    	            throw new NoSuchElementException("Start node '" + startNodeName + "' not found in the graph.");
    	        }
    	        outputArea.append("Running DFS from " + startNode.getName() + "...\n");
    	          long startTime = System.nanoTime();
    	         List<GraphNode> dfsResult = graph.dfs(startNode);
    	            long endTime = System.nanoTime();
    	        outputArea.append("DFS Result: ");
    	         for (GraphNode node : dfsResult){
    	            outputArea.append(node.getName() + " , ");
    	        }
    	        outputArea.append("\nTime taken: " + (endTime - startTime) / 1_000_000 + " ms\n");
    	    }catch (IllegalArgumentException e){
    	        outputArea.append("Warning: " + e.getMessage() + "\n");
    	    }catch (NoSuchElementException e) {
    	        outputArea.append("Warning: " + e.getMessage() + "\n");
    	    }catch (Exception e){
    	        outputArea.append("An unexpected error occurred: " + e.getMessage() + "\n");
    	    }finally{
    	        drawingPanel.repaint();
    	    }
    	     }
    	private void runPrim(){
    	    String startNodeName = startNodeField.getText();
    	    try {
    	        if (startNodeName == null  || startNodeName.trim().isEmpty()){
    	            throw new IllegalArgumentException("Start node name cannot be empty.");
    	        }
    	         GraphNode startNode= graph.getNodeByName(startNodeName);
    	       if (startNode == null) {
    	            throw new NoSuchElementException("Start node '" + startNodeName + "' not found in the graph.");
    	         }
    	          outputArea.append("Running Prim's algorithm from " + startNode.getName() + "...\n");
    	          long startTime = System.nanoTime();
    	           List<GraphEdge> primResult = graph.prim(startNode);
    	           long endTime = System.nanoTime();
    	        outputArea.append("Prim's Result: ");
    	          for (GraphEdge edge : primResult){
    	             outputArea.append("[" + edge.getFrom().getName() + " - " + edge.getTo().getName() + "] ");
    	        }
    	        outputArea.append("\nTime taken: " + (endTime - startTime) / 1_000_000 + " ms\n");
    	    }catch(IllegalArgumentException e){
    	        outputArea.append("Error: " + e.getMessage() + "\n");
    	     } catch (NoSuchElementException e) {
    	       outputArea.append("Error: " + e.getMessage() + "\n");
    	    }catch (Exception e){
    	        outputArea.append("An unexpected error occurred: " + e.getMessage() + "\n");
    	    } finally {
    	        drawingPanel.repaint();
    	    }
    	     }
    	private void runKruskal(){
    	    try{
    	         outputArea.append("Running Kruskal's algorithm...\n");
    	         long startTime = System.nanoTime();
    	         List<GraphEdge> kruskalResult = graph.kruskal();
    	          long endTime = System.nanoTime();
    	         outputArea.append("Kruskal's Result: ");
    	           for (GraphEdge edge : kruskalResult){
    	             outputArea.append("[" + edge.getFrom().getName() + " - " + edge.getTo().getName() + "] ");
    	         }
    	        outputArea.append("\nTime taken: " + (endTime - startTime) / 1_000_000 + " ms\n");
    	    }catch(UnsupportedOperationException e){
    	        outputArea.append("Error: Kruskal's algorithm is not supported for this graph.\n");
    	   }catch (IllegalStateException e){
    	        outputArea.append("Error: " + e.getMessage() + "\n");
    	    }catch (Exception e) {
    	         outputArea.append("An unexpected error occurred: " + e.getMessage() + "\n");
    	     }finally{
    	         drawingPanel.repaint();
    	    }
        	 }
    	private void runDijkstra(){
    	    try{
    	         String startNodeName = startNodeField.getText();
    	        if (startNodeName == null || startNodeName.trim().isEmpty()){
    	            throw new IllegalArgumentException("Start node name cannot be empty.");
    	         }
    	         GraphNode startNode = graph.getNodeByName(startNodeName);
    	      if (startNode == null){
    	            throw new NoSuchElementException("Start node '" + startNodeName + "' not found in the graph.");
    	        }
    	       outputArea.append("Running Dijkstra's algorithm from " + startNode.getName() + "...\n");
    	         long startTime = System.nanoTime();
    	          Map<GraphNode, Integer> distances = graph.dijkstra(startNode);
    	       long endTime = System.nanoTime();
    	         outputArea.append("Dijkstra's Result: ");
    	        for (Map.Entry<GraphNode, Integer> entry : distances.entrySet()){
    	            outputArea.append(entry.getKey().getName() + " (distance: " + entry.getValue() + ") ");
    	        }
    	         outputArea.append("\nTime taken: " + (endTime - startTime) / 1_000_000 + " ms\n");
    	    }catch (IllegalArgumentException e){
    	        outputArea.append("Error: " + e.getMessage() + "\n");
    	   }catch (NoSuchElementException e){
    	        outputArea.append("Error: " + e.getMessage() + "\n");
    	     }catch (UnsupportedOperationException e){
    	        outputArea.append("Error: Dijkstra's algorithm is not supported for this graph.\n");
    	   }catch (Exception e){
    	        outputArea.append("An unexpected error occurred: " + e.getMessage() + "\n");
    	    } finally{
    	        drawingPanel.repaint();
    	     }
    	    }
    private long measureExecutionTime(Runnable algorithm){
        long startTime = System.nanoTime();
         algorithm.run();
        return System.nanoTime() - startTime;
    }
    private void compareAlgorithms(){
         outputArea.append("Comparing BFS and DFS...\n");
       String startNodeName = startNodeField.getText();
        GraphNode startNode = graph.getNodeByName(startNodeName);
         if (startNode == null){
            outputArea.append("Start node not found.\n");
            return;
         }
        long bfsTime = measureExecutionTime(() -> graph.bfs(startNode));
          outputArea.append("BFS Time: " + bfsTime / 1_000_000 + " ms\n");
         long dfsTime = measureExecutionTime(() -> graph.dfs(startNode));
        outputArea.append("DFS Time: " + dfsTime / 1_000_000 + " ms\n");
        if (bfsTime < dfsTime) {
            outputArea.append("BFS is faster than DFS.\n");
        } else{
            outputArea.append("DFS is faster than BFS.\n");
          }
      outputArea.append("Comparing Prim's and Kruskal's...\n");
       long primTime = measureExecutionTime(() -> graph.prim(startNode));
        outputArea.append("Prim's Time: " + primTime / 1_000_000 + " ms\n");
         long kruskalTime = measureExecutionTime(() -> graph.kruskal());
        outputArea.append("Kruskal's Time: " + kruskalTime / 1_000_000 + " ms\n");
         if (primTime < kruskalTime){
            outputArea.append("Prim's is faster than Kruskal's.\n");
        } else{
            outputArea.append("Kruskal's is faster than Prim's.\n");
         }
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
             GraphAppGUI gui = new GraphAppGUI();
            gui.setVisible(true);
        });
    }
}
