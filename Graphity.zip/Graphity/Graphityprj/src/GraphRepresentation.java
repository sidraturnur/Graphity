import java.awt.Point;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set; 

public class GraphRepresentation{
     private List<GraphNode> nodes = new ArrayList<>();
    private List<GraphEdge> edges = new ArrayList<>();
    public List<GraphNode> highlightedNodes = new ArrayList<>();
    public List<GraphEdge> highlightedEdges = new ArrayList<>();

    public void clearHighlights() {
       highlightedNodes.clear();
        highlightedEdges.clear();
    }
    public List<GraphEdge> getAllEdges(){
        return edges;
    }
    public List<GraphNode> getAllNodes(){
        return nodes;
    }

    public void highlightNode(GraphNode node){
      if (!highlightedNodes.contains(node)){
            highlightedNodes.add(node);
        }
       }

    public void highlightEdge(GraphEdge edge){
      if (!highlightedEdges.contains(edge)){
            highlightedEdges.add(edge);
        }
       }

    public List<GraphNode> getHighlightedNodes(){
        return highlightedNodes;
    }

    public List<GraphEdge> getHighlightedEdges(){
        return highlightedEdges;
    }

    public List<GraphEdge> getEdgesFrom(GraphNode node) {
        List<GraphEdge> edgesFromNode = new ArrayList<>();
        for (GraphEdge edge : edges){
       if (edge.getFrom().equals(node) || edge.getTo().equals(node)){
                edgesFromNode.add(edge);
            }
        }
        return edgesFromNode;
    }
    public GraphEdge getConnectingEdge(GraphNode from, GraphNode to){
        for (GraphEdge edge : edges){
        if ((edge.getFrom().equals(from) && edge.getTo().equals(to)) || 
        (edge.getTo().equals(from) && edge.getFrom().equals(to))) {
                return edge;
            }
            }
        return null;
    }
    public void addNode(GraphNode node) {
        nodes.add(node);
    }
    public void addEdge(GraphNode from, GraphNode to, int weight) {
        GraphEdge edge = new GraphEdge(from, to, weight);
        edges.add(edge);
    }
    public void removeNode(GraphNode node) {
        edges.removeIf(edge -> edge.getFrom().equals(node) || edge.getTo().equals(node));
        nodes.remove(node);
    }
    public boolean removeEdge(GraphNode startNode, GraphNode endNode) {
        return edges.removeIf(edge -> 
            (edge.getFrom().equals(startNode) && edge.getTo().equals(endNode)) ||
            (edge.getFrom().equals(endNode) && edge.getTo().equals(startNode))
        );
        }
    public List<GraphNode> getNodes()
    {
        return nodes;
    }
    public List<GraphEdge> getEdges()
    {
        return edges;
    }
    public GraphNode getNodeByName(String name){
        for (GraphNode node : nodes) {
           if (node.getName().equals(name)){
               return node;
        }
      }
        return null; 
    }
 public GraphNode getNodeAtPosition(Point point){
    	 if (point == null){
    	        return null;
    	    }
        for (GraphNode node : nodes) {
            if (node.getBounds().contains(point)) {
                return node;
        }
     }
        return null;
    }
 public List<GraphNode> bfs(GraphNode startNode){
	   clearHighlights(); 
	   List<GraphNode> visitedNodes = new ArrayList<>();
	   Queue<GraphNode> queue = new LinkedList<>();
	    Set<GraphNode> visited = new HashSet<>();
	  queue.add(startNode);
	  visited.add(startNode);
	  highlightNode(startNode);
	   while (!queue.isEmpty()){
	  GraphNode currentNode = queue.poll();
	     visitedNodes.add(currentNode);
  for (GraphNode neighbor : getNeighbors(currentNode)) 
  {
	if (!visited.contains(neighbor)){
	     queue.add(neighbor);
	       visited.add(neighbor);
	      highlightNode(neighbor); 
        highlightEdge(getConnectingEdge(currentNode, neighbor));
	            }
	        }
	    }
	    return visitedNodes;
	}
 public List<GraphNode> dfs(GraphNode startNode){
     clearHighlights();
     highlightedNodes.add(startNode);
      List<GraphNode> visited = new ArrayList<>();
      dfsVisit(startNode, visited);
     return visited;
 }
 private void dfsVisit(GraphNode node, List<GraphNode> visited){
     visited.add(node);
      for (GraphEdge edge : getEdgesFrom(node)) {
        GraphNode neighbor = edge.getTo();
     if (!visited.contains(neighbor)) {
             highlightedEdges.add(edge);
             highlightedNodes.add(neighbor);
             dfsVisit(neighbor, visited);
       }
     }
   }
 public List<GraphEdge> prim(GraphNode startNode){
	   clearHighlights();
	   List<GraphEdge> mstEdges = new ArrayList<>();
	   Set<GraphNode> visited = new HashSet<>();
	  List<GraphEdge> pq = new ArrayList<>();
	   visited.add(startNode);
	   highlightedNodes.add(startNode);
	  for (GraphEdge edge : getEdgesFrom(startNode)) {
	        pq.add(edge);
	    }
	    for(int i= 0; i < pq.size() - 1;i++){
	   for (int j= i+ 1;j< pq.size(); j++){
	    if(pq.get(i).getWeight()> pq.get(j).getWeight()) 
	    {
	    			GraphEdge temp = pq.get(i);
	    			pq.set(i, pq.get(j));
	    			pq.set(j,temp);
	    		}
	    	}
	    	
	    }	    
	    while (!pq.isEmpty()){
	      GraphEdge edge = pq.get(0);
	       pq.remove(0);
	       GraphNode fromNode = edge.getFrom();
	      GraphNode toNode = edge.getTo();
	       GraphNode nextNode = visited.contains(fromNode) ? toNode : fromNode;
	        if (!visited.contains(nextNode)) {
	           mstEdges.add(edge);
	           highlightedEdges.add(edge);
	          highlightedNodes.add(nextNode); 
	            visited.add(nextNode);
	            for (GraphEdge nextEdge : getEdgesFrom(nextNode)){
	                    pq.add(nextEdge);
	                }
	            for(int i= 0; i < pq.size() - 1;i++){
	    	    for (int j= i+ 1;j< pq.size(); j++) 
	    	    {
	    	    		if(pq.get(i).getWeight()> pq.get(j).getWeight()) {
	    	    		GraphEdge temp = pq.get(i);
	    	    		pq.set(i, pq.get(j));
	    	   		pq.set(j,temp);
	    	    		}
	            	}
	           }
	       }
	    }

	    return mstEdges;
	}
    public List<GraphEdge> kruskal() {
        KruskalAlgorithm kruskalAlgorithm = new KruskalAlgorithm(this);
        return kruskalAlgorithm.execute();
    }
    public Map<GraphNode, Integer> dijkstra(GraphNode startNode) {
        DijkstraAlgorithm dijkstraAlgorithm = new DijkstraAlgorithm(this);
         return dijkstraAlgorithm.execute(startNode);
    } 
    public List<GraphNode> getNeighbors(GraphNode node) {
        List<GraphNode> neighbors = new ArrayList<>();
         for (GraphEdge edge : edges) {
            if (edge.getFrom().equals(node)) {
                neighbors.add(edge.getTo());
            } else if (edge.getTo().equals(node)) {
                neighbors.add(edge.getFrom());
           }
        }
        return neighbors;
    }
}
