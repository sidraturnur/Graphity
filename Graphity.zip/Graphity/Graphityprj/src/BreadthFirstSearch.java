import java.util.List;
import java.util.ArrayList;
import java.util.Queue;
import java.util.LinkedList;

public class BreadthFirstSearch {
    private GraphRepresentation graph;

    public BreadthFirstSearch(GraphRepresentation graph){
        this.graph = graph;
    }

    public List<GraphNode> execute(GraphNode startNode){
     graph.clearHighlights();
       List<GraphNode> visited = new ArrayList<>();
          Queue<GraphNode> queue = new LinkedList<>();
    queue.add(startNode);
     graph.highlightNode(startNode); 
     while (!queue.isEmpty()){
     GraphNode current = queue.poll();
     visited.add(current);
     for (GraphEdge edge : graph.getEdgesFrom(current)) {
                GraphNode neighbor = edge.getTo();
                if (!visited.contains(neighbor) && !queue.contains(neighbor))
                {
                    queue.add(neighbor);
                    graph.highlightNode(neighbor);
                    graph.highlightEdge(edge);
                }
             }
          }
        return visited;
    }
}
