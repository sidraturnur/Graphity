import java.util.*;

public class KruskalAlgorithm  
{
    private GraphRepresentation graph;
    private List<GraphEdge> mstEdges;
    public KruskalAlgorithm(GraphRepresentation graph){
        this.graph = graph;
        this.mstEdges = new ArrayList<>();
    }
   private Map<GraphNode, GraphNode> parent = new HashMap<>();
    private Map<GraphNode, Integer> rank = new HashMap<>();
     private void initialize() {
        for (GraphNode node : graph.getAllNodes()) {
            parent.put(node, node);
            rank.put(node, 0);
        }
    }
    private GraphNode find(GraphNode node){
        if (!parent.get(node).equals(node)) 
        {
            parent.put(node, find(parent.get(node)));
        }
        return parent.get(node);
    }
    private void union(GraphNode node1, GraphNode node2){
        GraphNode root1 = find(node1);
        GraphNode root2 = find(node2);
        if (rank.get(root1) > rank.get(root2))
        {
            parent.put(root2, root1);
        } else if (rank.get(root1) < rank.get(root2)) {
            parent.put(root1, root2);
        }else{
            parent.put(root2, root1);
            rank.put(root1, rank.get(root1) + 1);
        }
        }
    public List<GraphEdge> execute(){
       graph.clearHighlights();
        List<GraphEdge> edges = new ArrayList<>(graph.getAllEdges());
         for (int i = 0; i < edges.size() - 1; i++){
            for (int j = 0; j < edges.size() - i - 1; j++){
                if (edges.get(j).getWeight() > edges.get(j + 1).getWeight()){
                   GraphEdge temp = edges.get(j);
                     edges.set(j, edges.get(j + 1));
                    edges.set(j + 1, temp);
                }
            }
        }
  initialize();
        for (GraphEdge edge : edges){
             GraphNode from = edge.getFrom();
            GraphNode to = edge.getTo();
              if (find(from) != find(to)) {
             mstEdges.add(edge);
             graph.highlightedEdges.add(edge);
             graph.highlightedNodes.add(from);
           graph.highlightedNodes.add(to);
            union(from, to);
            }
             }
    
        return mstEdges;
    }
}
