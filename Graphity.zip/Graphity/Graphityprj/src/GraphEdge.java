public class GraphEdge {
    private GraphNode from;
    private GraphNode to;
     private int weight;
     public GraphEdge(GraphNode from, GraphNode to, int weight) {
        this.from = from;
        this.to = to;
        this.weight = weight;
    }
    public GraphNode getFrom(){
        return from;
    }
    public GraphNode getTo(){
        return to;
    }
    public int getWeight(){
        return weight;
    }
    }
