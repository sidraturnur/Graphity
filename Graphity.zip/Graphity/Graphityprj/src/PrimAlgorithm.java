import java.util.*;

public class PrimAlgorithm  {
    private GraphRepresentation graph;
    public PrimAlgorithm(GraphRepresentation graph){
        this.graph = graph;
    }
    public List<GraphEdge> execute(GraphNode startNode) 
    {
        List<GraphEdge> mst = new ArrayList<>();
        Set<GraphNode> visited = new HashSet<>();
        PriorityQueue<GraphEdge> edgeQueue = new PriorityQueue<>(Comparator.comparingInt(GraphEdge::getWeight));
         visited.add(startNode);
           addEdges(startNode, edgeQueue, visited);
           while (!edgeQueue.isEmpty()) {
         GraphEdge edge = edgeQueue.poll();
          GraphNode toNode = edge.getTo();
             if (!visited.contains(toNode)){
            visited.add(toNode);
            mst.add(edge);
            addEdges(toNode, edgeQueue, visited);
             }
          }
        return mst;
    }
    private void addEdges(GraphNode node, PriorityQueue<GraphEdge> edgeQueue, Set<GraphNode> visited) 
    {
        for (GraphEdge edge : graph.getEdges()){
        	GraphNode neighbor;
        	 if (edge.getFrom().equals(node)){
        	    neighbor = edge.getTo();
        	}else{
        	    neighbor = edge.getFrom();
        	 }
            if (neighbor != null && !visited.contains(neighbor)) {
               edgeQueue.add(edge);
            }

           }
         }
      }